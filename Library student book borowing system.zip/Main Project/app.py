# app.py

from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_cors import CORS
import os
from datetime import datetime
import sqlite3

app = Flask(__name__)
CORS(app)

# Establish database connection
def get_db_connection():
    conn = sqlite3.connect('library_borrow.db')
    conn.row_factory = sqlite3.Row
    return conn

# Create table for AI Book Borrowing Recognition System
def create_table():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS borrow_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name TEXT NOT NULL,
            book_title TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            action TEXT DEFAULT 'borrow' -- This is a SQL comment, or remove the line entirely
        )
    """)
    conn.commit()
    conn.close()

create_table()

# === Route: Home (Prediction) ===
@app.route('/')
def index():
    return render_template('index.html')

# === Route: Student Training Page ===
@app.route('/train/student')
def train_student_page():
    return render_template('train_student.html')

# === Route: Save Prediction ===
@app.route('/log', methods=['POST'])
def log_borrow():
    data = request.json
    student_name = data.get('student_name')
    book_title = data.get('book_title')
    
    if not student_name or not book_title:
        return jsonify({'status': 'error', 'message': 'Student name and book title are required'}), 400

    now = datetime.now()
    current_date = now.strftime("%Y-%m-%d")
    current_time = now.strftime("%H:%M:%S")

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO borrow_log (student_name, book_title, date, time, action) VALUES (?, ?, ?, ?, ?)",
        (student_name, book_title, current_date, current_time, 'borrow')
    )
    conn.commit()
    conn.close()

    return jsonify({'status': 'success', 'message': f"Logged: {student_name} borrowed {book_title}"})

@app.route('/alldata')
def alldata():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM borrow_log ORDER BY date DESC, time DESC")
    data = cursor.fetchall()
    conn.close()
    return render_template('alldata.html', data=data)


if __name__ == '__main__':
    app.run(debug=True)