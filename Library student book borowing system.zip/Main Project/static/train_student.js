let video;
let featureExtractor;
let classifier;
let currentCounts = {}; // To store the count of images per class

// --- p5.js Setup Function ---
function setup() {
    const canvas = createCanvas(640, 480);
    canvas.parent('videoContainer'); 

    video = createCapture(VIDEO);
    video.size(640, 480);
    video.hide();

    select('#status').html('Status: Loading MobileNet...');
    featureExtractor = ml5.featureExtractor('MobileNet', modelReady);
}

// --- p5.js Draw Function ---
function draw() {
    image(video, 0, 0, width, height); 
}

// --- MobileNet Model Ready Callback ---
function modelReady() {
    select('#status').html('Status: MobileNet Loaded! Creating Student Classifier...'); // CHANGED HERE
    classifier = featureExtractor.classification(video, videoReady);
}

// --- Video Ready Callback ---
function videoReady() {
    select('#status').html('Status: Video Ready! Start adding student data...'); // CHANGED HERE
    console.log('Video and student classifier ready. Start adding images!'); // CHANGED HERE
}

// --- Add Image Data Function ---
function addImage(label) {
    classifier.addImage(video, label);
    console.log(`Added image for student class: ${label}`); // CHANGED HERE

    if (currentCounts[label]) {
        currentCounts[label]++;
    } else {
        currentCounts[label] = 1;
    }
    
    const sanitizedId = label.replace(/ /g, '_').replace(/[^a-zA-Z0-9_]/g, ''); 
    const countElement = select(`#${sanitizedId}_count`); 

    if (countElement) {
        countElement.html(currentCounts[label]);
    }
    
    select('#status').html(`Status: Added image for ${label}. Total: ${currentCounts[label]}`);
}

// --- Train Model Function ---
function trainModel() {
    const uniqueLabels = Object.keys(currentCounts);
    if (uniqueLabels.length === 0 || uniqueLabels.some(label => currentCounts[label] === 0)) {
        alert("Please add at least one image for EACH student class before training!");
        return;
    }

    select('#status').html('Status: Training student model... Please wait.');
    select('#loss').html('Loss: Calculating...');
    console.log('Starting student model training...');

    //  Use only the two callbacks
    classifier.train(whileTraining, trainingComplete);
}


// --- While Training Callback (Optional) ---
function whileTraining(lossOrStatus) { // Renamed parameter for clarity
    if (typeof lossOrStatus === 'string') {
        if (lossOrStatus === 'Finished') {
            // This is the signal for training complete but before trainingComplete() is fired
            // You can optionally update status here, but trainingComplete() usually handles final status
        } else {
            // It's a string message like 'Calculating...'
            select('#loss').html(`Loss: ${lossOrStatus}`);
        }
    } else if (typeof lossOrStatus === 'number') {
        select('#loss').html(`Loss: ${lossOrStatus.toFixed(4)}`);
        console.log(`Loss: ${lossOrStatus.toFixed(4)}`);
    } else {
        // Fallback for unexpected values
        select('#loss').html('Loss: N/A');
    }
}

// And ensure your trainingComplete function handles the actual completion logic
function trainingComplete() {
    select('#status').html('Status: Student model training complete! You can now save it.');
    select('#loss').html('Loss: Training Finished'); // Final status
    console.log('Student model training complete!');
}

// --- Save Model Function ---
function saveModel(modelName) {
    if (classifier) {
        select('#status').html(`Status: Saving ${modelName} files...`);
        classifier.save(modelName); 
        select('#status').html(`Status: ${modelName} files downloaded! Move them to static/models/${modelName}/ folder.`);
        console.log(`Model files saved as ${modelName}! Please move them from your downloads folder to project_root/static/models/${modelName}/`);
    } else {
        alert('No model to save. Please train a model first.');
    }
}