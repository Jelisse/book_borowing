let video;
let featureExtractor;
let studentClassifier;
let currentStudent = "Detecting Student...";
let studentModelLoaded = false;

const studentModelPath = 'static/models/student_model/model.json';

// --- p5.js Setup Function ---
function setup() {
    const canvas = createCanvas(640, 480);
    canvas.parent('videoContainer');

    video = createCapture(VIDEO);
    video.size(640, 480);
    video.hide();

    select('#prediction').html('Prediction: Loading Student Model...');

    // ✅ Use featureExtractor to load the classifier properly
    featureExtractor = ml5.featureExtractor('MobileNet', () => {
        studentClassifier = featureExtractor.classification(video, () => {
            studentClassifier.load(studentModelPath, studentModelReady);
        });
    });
}

// --- p5.js Draw Function ---
function draw() {
    image(video, 0, 0, width, height);
    fill(255);
    textSize(24);
    textAlign(LEFT, BOTTOM);
    text(`Student: ${currentStudent}`, 10, height - 10);
}

// --- Student Model Ready Callback ---
function studentModelReady() {
    console.log('Student model loaded!');
    studentModelLoaded = true;
    select('#prediction').html('Prediction: Student model loaded! Starting classification...');
    classifyVideo();
}

// --- Main Classification Function ---
function classifyVideo() {
    if (!video.loadedmetadata || !studentModelLoaded) {
        setTimeout(classifyVideo, 100);
        return;
    }

    studentClassifier.classify(gotStudentResult); // ✅ No need to pass `video` again
    setTimeout(classifyVideo, 100);
}

// --- Got Student Result Callback ---
function gotStudentResult(error, results) {
    if (error) {
        console.error("Student Classifier Error:", error);
        currentStudent = "Error!";
    } else if (results && results[0]) {
        currentStudent = results[0].label;
    } else {
        currentStudent = "Unknown Student";
    }
    updatePredictionDisplay();
}

// --- Update the main prediction display ---
function updatePredictionDisplay() {
    select('#prediction').html(`Recognized Student: ${currentStudent}`);
}

// --- Send Log Function ---
function sendLog() {
    let studentToSend = currentStudent;

    if (studentToSend.includes("Detecting") || studentToSend.includes("Error") ||
        studentToSend === "Unknown Student" || studentToSend === "Background") {
        alert("Please ensure a specific student is recognized before logging a borrow event.");
        return;
    }

    const bookTitleInput = document.getElementById('bookTitleInput');
    let bookTitle = bookTitleInput.value.trim();

    if (bookTitle === "") {
        alert("Please enter the book title before logging the borrow event.");
        return;
    }

    fetch('/log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ student_name: studentToSend, book_title: bookTitle })
    })
    .then(res => {
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        return res.json();
    })
    .then(data => {
        if (data.status === 'success') {
            alert(data.message);
            bookTitleInput.value = '';
            updatePredictionDisplay();
        } else {
            alert("Error logging borrow event: " + (data.message || "Unknown error"));
        }
    })
    .catch(error => {
        console.error('Fetch Error:', error);
        alert('Failed to log borrow event. Check console for details.');
    });
}